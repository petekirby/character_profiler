classes = {
    'focal_set' : ('a','b','c'),
    'comp_set1' : ('d','e','f'),
    'comp_set2' : ('g','h','i'),
}